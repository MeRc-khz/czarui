# bzr-dial-ui v1.0.0

Thank you for purchasing bzr-dial-ui! 🎉

## Quick Start

1. Include the component in your HTML:
```html
<script src="bzr-dial.js"></script>
```

2. Use it in your page:
```html
<bzr-dial 
    size="300"
    color="#00ff9d"
    data-title="My Dial">
</bzr-dial>
```

## Documentation

Full documentation available at: https://bzzrr.link/docs

## Support

- Email: support@bzzrr.link
- Documentation: https://bzzrr.link/docs
- Updates: You'll receive email notifications

## License

This is a commercial license. See LICENSE.txt for details.

Your license key: [Included in your purchase email]

---

Built with ❤️ by bzr-dial-ui
