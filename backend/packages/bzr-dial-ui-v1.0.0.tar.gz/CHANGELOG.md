# Changelog

## v1.0.0 (2026-02-05)

### Initial Release

- Premium dial component
- Full customization options
- Media support (images, video, audio)
- Physics-based interactions
- Responsive design
- Cross-browser compatible

---

For updates, check your email or visit: https://bzzrr.link
